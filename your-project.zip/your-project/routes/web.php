<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
// First Route method – Root URL will match this method
/*
 Route::get('/register',['as'=>'registering', function () {
    return view('welcome');
}]);

// Second Route method – Root URL with ID will match this method
Route::get('ID/{id}',function($id){
   echo 'ID: '.$id;
});

// Third Route method – Root URL with or without name will match this method
Route::get('/user/{name?}',function($name = 'Pavi'){
   echo "Name: ".$name;
});

/*Route::get('dashboard/', function () {
    return view('dashboard');
});*/

/*Route::get('role/{name?}',[
   'middleware' => 'Role:editor',
   'uses' => 'TestController@index',
]);

Route::get('role',[
   'middleware' => 'Role:user',
   'uses' => 'TestController@index1',
]);


Route::get('terminate',[
   'middleware' => 'terminate',
   'uses' => 'ABCController@index',
]);

/*Route::get('profile', [
   'middleware' => 'auth',
   'uses' => 'employeecontroller@showProfile'
]);*/
/*
Route::get('/employeecontroller/path',[
'middleware' => 'First',
'uses' => 'employeecontroller@showPath',
]);

//curd operation in the controllr
Route::resource('my','MyempController');

/*
Route::get('/register',function(){
   return view('register');
});*/
/*
Route::post('/emp/register',array('uses'=>'EmpRegistration@postRegister'));

Route::get('rr','employeecontroller@showPath');
Route::get('blade', function () {
   return redirect()->action('employeecontroller@showPath');
});
*/



Route::group(['middleware' => ['web']], function () {
    Route::get('/', function () {
        return view('auth.login');
            })->middleware('guest');
    Route::get('401', function () {
        return view('errors.401');
    });

    Route::get('users/login', 'Auth\AuthController@getLogin');
    Route::post('users/login', 'Auth\AuthController@postLogin');
    Route::auth();
});  

Auth::routes();

Route::get('/home', 'HomeController@index');
Route::get('/default', function(){
	return view('includes.default');
});


Route::get('/insert','employeecontroller@insertform');
Route::post('/create','employeecontroller@insert');

