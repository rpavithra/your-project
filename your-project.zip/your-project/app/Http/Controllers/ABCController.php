<?php

namespace employeeapp\Http\Controllers;

use Illuminate\Http\Request;
use employeeapp\Http\Requests;
use employeeapp\Http\Controllers\Controller;

class ABCController extends Controller
{
     public function index(){
      echo "<br>ABC Controller.";
   }
}
