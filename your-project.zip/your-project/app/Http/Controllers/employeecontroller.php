<?php

namespace employeeapp\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use employeeapp\Http\Requests;
use employeeapp\Http\Controllers\Controller;

class employeecontroller extends Controller
{
 //public function __construct(){
   //   $this->middleware('auth');
   //}	
	
	  public function insertform(){
	
		  return view('registerfrm');
	   }
	
   public function insert(Request $request){
	  
      $name = $request->name;
      $designation = $request->designation;
        // echo $name;
       //  echo $designation;
       //$pdo = DB::connection()->getPdo();
       //$users = DB::connection('pholearndb');
        
        
        
     $record= DB::table('employee')->insert(['name' => $name, 'designation' => $designation]);
    //  $record=DB::table('employee')->get();
      
    //  insert('insert into employee (name) (designation) values(?)',[$name] ,[$designation]);
      echo "Record inserted successfully.<br/>";
      echo "<a href = 'insert'>Click Here</a> to go back.";
   }
}
