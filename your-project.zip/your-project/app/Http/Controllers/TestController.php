<?php

namespace employeeapp\Http\Controllers;

use Illuminate\Http\Request;
use employeeapp\Http\Requests;
use employeeapp\Http\Controllers\Controller;

class TestController extends Controller
{
    public function index(){
      echo "<br>Test Controller.";
   }
   
   public function index1(){
      echo "<br>Test Controller 1.";
   }
}
?>