<?php

namespace employeeapp\Http\Controllers;

use Illuminate\Http\Request;

class UserController extends Controller
{
    //
}
