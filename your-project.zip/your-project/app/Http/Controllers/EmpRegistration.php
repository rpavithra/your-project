<?php

namespace employeeapp\Http\Controllers;

use Illuminate\Http\Request;
use employeeapp\Http\Requests;
use employeeapp\Http\Controllers\Controller;


class EmpRegistration extends Controller
{
     public function postRegister(Request $request){
      //Retrieve the name input field
      $name = $request->input('name');
      echo 'Name: '.$name;
      echo '<br>';
      
      //Retrieve the username input field
    $designation = $request->designation;
      echo 'Designation: '.$designation;
      echo '<br>';
      
      //Retrieve the password input field
     //$password = $request->password;
     // echo 'Password: '.$password;
   }
}
