<!doctype html>
<html>
<head>
<!-- my head section goes here -->
<!-- my css and js goes here -->
</head>
<body>
<div class="container">
  <header> <?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </header>
  <div class="sidebar"> <?php echo $__env->make('includes.sider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </div>
  <div class="contents"> <?php echo $__env->yieldContent('content'); ?> </div>
  <footer> <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> </footer>
</div>
</body>
</html>