<!DOCTYPE html>
<head>
<body>
<h1>Dashboard</h1>
<hr>
</body>
</head>
</html>