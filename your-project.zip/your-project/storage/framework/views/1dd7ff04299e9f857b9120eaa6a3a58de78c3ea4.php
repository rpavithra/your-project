<!doctype html>
<html>
<head>


<?php $__env->startSection('content'); ?>


</head>

<body>
	<!-- <div class="container">
	
	<header class = "row">
	<!--<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
	</header>
	
	<div id="sidebar" class="col-md-4">
           <!-- <?php echo $__env->make('includes.sider', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
	
	<div id="main" class="row">
	
	<!-- <?php echo $__env->yieldContent('content'); ?>
	-->
	
	      <form action="/create" method = "post">
         <input type = "hidden" name = "_token" value = "<?php echo csrf_token() ?>">
    
         <table>
            <tr>
               <td>Name</td>
               <td><input type = "text" name = "name" /></td>
            </tr>
         
            <tr>
               <td>Designation</td>
               <td><input type = "text" name = "designation" /></td>
            </tr>
         
           <!-- <tr>
               <td>Password</td>
               <td><input type = "text" name = "password" /></td>
            </tr>-->
         <tr>
               <td colspan = "2" align = "center">
                  <input type = "submit" value = "Register" />
               </td>
            </tr>
         </table>
      
      </form>
   
   </div>
   
    <!--  <footer class="row">
    <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </footer>
    </div> -->
    <?php $__env->stopSection(); ?>
   </body> 

</html>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>