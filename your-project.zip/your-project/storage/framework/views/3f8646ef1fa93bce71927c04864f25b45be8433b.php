<header class="main-header">
        <!-- Logo 
        <a href="<?php echo e(url('create')); ?>" class="logo"> -->
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b> </b></span>
        <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

    <section class="content">
			<?php echo $__env->make('registerfrm', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Your Page Content Here -->
            <?php echo $__env->yieldContent('content'); ?>
        </section><!-- /.content -->
    </div>
        </a>
</header>



