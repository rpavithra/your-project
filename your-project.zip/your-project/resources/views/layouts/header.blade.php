<header class="main-header">
<!--<header class="w3-container w3-green">-->

        <!-- Logo 
        <a href="{{ url('create') }}" class="logo"> -->
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b> </b></span>
        <body class="hold-transition skin-blue sidebar-mini">
    <div class="wrapper">

    <section class="content">
			@include('registerfrm')
            <!-- Your Page Content Here -->
            @yield('content')
        </section><!-- /.content -->
    </div>
        </a>

</header>



