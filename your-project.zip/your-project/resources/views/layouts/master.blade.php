<html>
   
   <head>
      <title>@yield('title')</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
       <link href="/css/napp.css" rel="stylesheet">
       <link rel="stylesheet" href="https://www.w3schools.com/lib/w3.css">
       
   </head>
   
   <body>
   
 
   <div class="w3-container w3-green">
      <p> <a href="http://yahwehsolutions.com/"><img src="/images/yahweh.png" alt="Yahweh Solution" height="42" width="132"><h2>Yahweh Software Solutions </h2> </a></p>
   </div>
   
    <ul class="w3-navbar">
  <li><a href="javascript:void(0)" onclick="openCity('London')">Home</a></li>
  <li><a href="javascript:void(0)" onclick="openCity('Paris')">Register</a></li>
  <li><a href="javascript:void(0)" onclick="openCity('Tokyo')">Contact us</a></li>
</ul>

   <div id="London" class="city">
  <h2>London</h2>
  <p>London is the capital of England.</p>
</div>

<div id="Paris" class="city" style="display:none">
  <h2>Paris</h2>
  <p>Paris is the capital of France.</p>
</div>

<div id="Tokyo" class="city" style="display:none">
  <h2>Tokyo</h2>
  <p>Tokyo is the capital of Japan.</p>
</div>
   
   <div class="w2-row-padding">
   
   <div class="w2-third">
    @yield('content')
  </div>

   </div>
   
   <div class="w3-container w3-green">
   <footer> @include('includes.footer') </footer>
   </div>
   </body>
</html>
