<!doctype html>
<html>
<head>
<!-- my head section goes here -->
<!-- my css and js goes here -->
</head>
<body>
<div class="container">
  <header> @include('includes.header') </header>
  <div class="sidebar"> @include('includes.sider') </div>
  <div class="contents"> @yield('content') </div>
  <footer> @include('includes.footer') </footer>
</div>
</body>
</html>